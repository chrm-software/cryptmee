
WorkerScript.onMessage = function(message) {
                 WorkerScript.sendMessage({ 'reply': ready })
}
